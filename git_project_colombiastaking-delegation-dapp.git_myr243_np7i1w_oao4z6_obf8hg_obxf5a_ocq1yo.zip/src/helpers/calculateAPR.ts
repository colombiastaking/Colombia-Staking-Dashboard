// Deprecated: No longer used. See helpers/colsAprTable.ts for new logic.
export {};
